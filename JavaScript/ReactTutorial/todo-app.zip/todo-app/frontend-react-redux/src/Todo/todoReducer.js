const INITIAL_STATE = {
    description: "",
    list: []
}

export default ( state = INITIAL_STATE, action ) => {
    switch( action.type ){
        case "CHANGE_DESCRIPTION": 
            // console.log( action.payload, state );
            return {
                ...state,
                description: action.payload
            }
        
        case "SEARCH":
            console.log( action.payload, state );
            return {
                ...state,
                list: action.payload.data
            }

        case "ADICIONA":
            console.log( state );
            return {
                ...state,
                description: ""
            }

        default:
            console.log( "ACTION NÃO ENCONTRADA" );
            return state;
    }
}