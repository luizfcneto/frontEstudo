import React from "react";
import "./section.css";

export default ( props ) => {

    return ( 
        <div className="section">
            <h3> Section Area </h3>
            
        </div>
    )
}