import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { inc, dec, alterarConteudo } from "./counterActions";


const Counter = ( props ) => {
    return (
        <div> 
            <h2> { props.counter.number } </h2>
            <input onChange={ props.alterarConteudo } value={ props.counter.step } type="number" />
            <button onClick={ props.dec } > Dec </button>
            <button onClick={ props.inc } > Inc </button>
            
        </div>
    )
}
// function mapStateToProps( state ){
//     return {
//         counter: state.counter
//     };
// };
//ou
const mapStateToProps = ( state ) => {
    return {
        counter: state.counter
    }
};


// function mapDispatchToProps( dispatch ){
//     return connect( { inc, dec, alterarConteudo }, Counter );
// }
//ou
const mapDispatchToProps = ( dispatch ) => {
    return bindActionCreators( {
        inc,
        dec,
        alterarConteudo
    }, dispatch );
};

export default connect( mapStateToProps, mapDispatchToProps )( Counter );