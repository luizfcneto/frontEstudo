import React from 'react';
import { Header } from "./components/Header";
import "../src/style/global.css";

function App() {
  return (
    <div>
      <Header />
    </div>
  );
}

export default App;
