import React from "react";

/* Importando o método connect do react-redux para mapear state( store )
 para props de TodoForm 
*/
import { connect } from "react-redux"

/* Importando o método bindActionCreators do redux para associar a ação
    devida para este componente TodoForm
*/
import { bindActionCreators } from "redux";

/* Importando os métodos/funções que representam as actions que serão utilizadas
    por este componente TodoForm, neste caso o "changeDescription" e search
*/
import { adiciona, changeDescription, search, clear } from "./todoActions";

import GridCss from "../Template/grid";
import IconButton from "../Template/iconButton";

/* Como a função search é uma requisição get no bd para captar os dados
    e atualizar exibição deles lista, devemos utilizar o método 
    componentWillMount(), só que este método só é possível de ser utilizado em 
    Classes de Componentes, por este motivo iremos refatorar o Componente 
    TodoForm para uma classe.
*/

class TodoForm extends React.Component{

    constructor( props ){
        super( props );

        this.keyHandler = this.keyHandler.bind( this );
    }

    // Função que reconhece teclas clicadas para associar a adicionar tarefa, e limpar
    keyHandler( e ) {
        const { adiciona, search, description } = this.props;
        if( e.key === "Enter" ){
            console.log( e.key )
            if( e.shiftKey === true ){
                // this.props.handleSearch() 
                search()
            }else{
                // this.props.handleAddEvent()
                adiciona( description )
            }
        }else if( e.key === "Escape" ) {
            // this.props.handleClear();
            this.props.clear();
        }
    }

    // função componenteWillMount() que utiliza a função search()
    componentWillMount(){
        this.props.search()
    }


    render(){
        const { adiciona, search, description } = this.props;
        return (
            <div role="form" className="todoForm">
                <GridCss cols="12 9 10">
                    <input 
                        id="description" 
                        className="form-control"
                        placeholder="Adicione uma tarefa..." 
                        
                        // Método alterado para utilizar a action changeDescription
                        // onChange={ props.handleChange }
                        onChange={ this.props.changeDescription }
    
                        //Adicionamos o manipulador de tecla no input
                        onKeyUp={ this.keyHandler }
                        value={ this.props.description }
                    />
                </GridCss>
    
                <GridCss cols="12 3 2">
                    <IconButton 
                        style="btn btn-primary" 
                        icon="fa fa-plus" 
                        // onClick={ this.props.handleAddEvent } 
                        onClick={ () => adiciona( description ) }
                    />
    
                    <IconButton
                        style="btn btn-info"
                        icon="fa fa-search"
                        onClick={ () => search() }
                        // onClick={ this.props.handleSearch }
                        // onClick={ this.props.search }
                    >
                    </IconButton>
    
                    <IconButton
                        style="btn btn-default"
                        icon="fa fa-eraser" 
                        onClick={ this.props.clear }
                    >
                    </IconButton>
                </GridCss>
    
            </div>
        )
    }
    
}

/* Método mapStateToProps() para pegar objetos do store( state ) 
e mapear para props de TodoForm
*/
const mapStateToProps = ( state ) => {
    // console.log( state );
    return {
        description: state.todo.description
    }
}

/* Método mapDispatchToProps() para associar as funções/actions que serão utilizadas
por este componente
*/
const mapDispatchToProps = ( dispatch ) => {
    return bindActionCreators( {
        adiciona,
        changeDescription,
        search,
        clear
    }, dispatch );
}

export default connect( mapStateToProps, mapDispatchToProps ) ( TodoForm );