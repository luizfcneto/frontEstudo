import React from "react";

export default ( props ) => {
    return (
        <div className={ props.divGridClass }>
            <input 
                className={ props.inputClass }
                type={ props.type }
                value={ props.value }
                placeholder={ props.placeHolder }
                onChange={ props.inputHandler }
            />
        </div>
    )
}