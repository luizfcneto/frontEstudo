import React from "react";

export default ( props ) => {
    return ( 
        <div> 
            <h1> Todo List </h1>
        </div>
    )
}