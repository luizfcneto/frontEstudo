import React from "react";
import "./input.css";

export default ( props ) => {

    return (
        <div className="col-xs-6">
            <input 
                className={ props.inputClass }
                type={ props.type }
                value={ props.value }
                placeholder={ props.placeHolder }
                onChange={ props.inputHandler }
            />
        </div>
    );
}