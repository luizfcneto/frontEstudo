import React from "react";
import FormAgendamento from "../../../Components/User/Services/Agendamento/FormAgendamento";

import Header from "../../../Common/Header";
import Footer from "../../../Common/Footer";


class Agendamento extends React.Component{
    // constructor( props ){
    //     super( props );


    // }

    render(){
        return(
            <div className="agendamento">
                <Header logado="true" />
                <FormAgendamento />
                <div className="row">
                    


                </div>
                
                <Footer />
            </div>
        )
    }




}
export default Agendamento;