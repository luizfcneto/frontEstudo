import React from "react";

import PageHeader from "../Template/PageHeader";

export default ( props ) => {
    return (
        <div>
            <PageHeader name="Sobre" small="Nós" />
        </div>
    )
}