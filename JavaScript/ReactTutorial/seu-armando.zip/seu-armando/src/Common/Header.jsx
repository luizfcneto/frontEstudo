import React from "react";
import "./header.css";

export default ( props ) => {
    return (
        <nav className="navbar navbar-inverse navbar-fixed" id="navId">

            <div className="container-fluid">
                <div className="navbar-header">
                    <a className="navbar-brand" href="/" >
                        <img id="img_logo" alt="logo" src={ props.img_src } />
                    </a>
                </div>

                <div className="collapse navbar-collapse">
                    <ul className="nav navbar-nav"> 
                        <li role="presentation" className="active"> 
                            <a href="/"> Home </a>
                        </li> 

                        <li role="presentation" className="active"> 
                            <a href="/solicitar-orcamento"> Solicitar Orcamento </a>
                        </li>

                        <li role="presentation" className="active"> 
                            <a href="/cadastro"> Cadastro </a>     
                        </li>

                        <li role="presentation" className="active">
                            <a href="/login"> Login </a>
                        </li> 
                    </ul>

                    <form className="navbar-form navbar-right" >
                        <div className="form-group">
                            <input type="text" className="form-control" placeholder="Procurar" />
                        </div>
                        <button type="submit" className="btn btn-default"> Pesquisar </button>
                    </form>
                </div>                
                
            </div>
            
        </nav>
        
    )
}