// Conectando com axios para pegar dados do backend:
import axios from "axios";

// definindo a url do axios
const URL = "http://localhost:3003/api/todos";

export const changeDescription = ( event ) => {
    return {
        type: "CHANGE_DESCRIPTION",
        payload: event.target.value
    }
}

// Como esse método faz uma requição assincrona precisamos utilizar um middleware
export const search = () => {
    const request = axios.get( `${URL}?sort=-createdAt` );
    return {
        type: "SEARCH",
        payload: request
    }

}
