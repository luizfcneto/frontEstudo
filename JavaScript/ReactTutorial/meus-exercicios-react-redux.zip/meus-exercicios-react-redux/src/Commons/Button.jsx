import React from "react";


export default ( props ) => {
    return (
        <div className={ props.divClassBtn }> 
            <button 
                type="button"
                className={ props.btnClass }
                onClick={ props.add }
            > 
                { props.value } 
            </button>  
        </div>
        
    )
}