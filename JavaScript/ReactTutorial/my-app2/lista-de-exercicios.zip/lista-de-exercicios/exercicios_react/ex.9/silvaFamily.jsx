import React from 'react'
import Member from './member'

export default props => (
    <div>
        <Member name='João' lastName='Silva' />
        <Member name='Maria' lastName='Silva' />
        <Member name='Jose' lastName='Silva' />
        <Member name='Pedro' lastName='Silva' />
    </div>
)