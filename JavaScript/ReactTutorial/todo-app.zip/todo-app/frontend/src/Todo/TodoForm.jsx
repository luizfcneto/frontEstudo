import React from "react";

import GridCss from "../Template/grid";
import IconButton from "../Template/iconButton";

export default ( props ) => {
    return (
        <div role="form" className="todoForm">
            <GridCss cols="12 9 10">
                <input 
                    id="description" 
                    className="form-control"
                    placeholder="Adicione uma tarefa..." 
                    onChange={ props.handleChange }
                    value={ props.description }
                />
            </GridCss>

            <GridCss cols="12 3 2">
                <IconButton 
                    style="btn-primary" 
                    icon="fa fa-plus" 
                    onClick={ props.handleAddEvent } 
                />
            </GridCss>

        </div>
    )
}