import React from "react";
import "./form.css";
// import "./node_modules/bootstrap/dist/css/bootstap.css"
import "bootstrap/dist/css/bootstrap.min.css";
import FormCadastro from "./FormCadastro";

class Cadastro extends React.Component {

    constructor( props ){
        super( props );

        this.state = {
            // Como definir um estado de um array de objetos? 
            //R: Estruturar o objeto, declarar um array vazio, inserir objetos nesse array.
            
            usuario: {
                email: "",
                login: "",
                senha: "",
                confirmarSenha: "",
                dataNascimento: "",
                cpf: ""
            },
            listaUsuarios: []
            
        }

        this.inputHandler = this.inputHandler.bind( this );
        this.addCadastro = this.addCadastro.bind( this );
    }

    encrypt( password ) {
        let pass = password;
        let ans = [];
        for( let i = 0; i < pass.length; i++ ){
            ans.push( "*" );
        }
        ans = ans.join("");
        return ans;
    }

    // Função que escuta inputs
    inputHandler( event ) {
        // console.log( "input alterado em:", event.target.placeholder );
        // console.log( event.target.value );

        switch( event.target.placeholder ){
            case "Email":
               
                this.setState( {
                    ...this.state,
                    usuario: {
                        ...this.state.usuario,
                        email: event.target.value
                    }
                } );
                break;
            
            case "Login":
                    
                this.setState( {
                    usuario: {
                        ...this.state.usuario,
                        login: event.target.value
                    }
                } );
                break;
            
            case "Senha":
                let password = this.encrypt( event.target.value );
                
                this.setState( {
                    usuario: {
                        ...this.state.usuario,
                        senha: password 
                    }
                } );
                break;

            case "dataNascimento":
                
                this.setState( { 
                    ...this.state,
                    usuario: {
                        ...this.state.usuario,
                        dataNascimento: event.target.value
                    }
                } )
                break;

            case "CPF":

                this.setState( {
                    ...this.state,
                    usuario: {
                        ...this.state.usuario,
                        cpf: event.target.value
                    }
                } )
                break;

            default:
                console.log( "placeHolder invalido", event.target.placeholder );

        }
    }

    clearUsuario(){
        this.setState( {
            ...this.state,
            usuario: {
                email: "",
                login: "",
                senha: "",
                confirmarSenha: "",
                dataNascimento: "",
                cpf: ""
            }
        } );
    }

    //Funcao de adicionar campos do formulario para cadastro:
    addCadastro() {
        // console.log( "this.addCadastro chamado" );

        let usuario = this.state.usuario;
        if( usuario.email !== null || usuario.login !== null || usuario.senha !== null ){
            let lista = this.state.listaUsuarios;
            lista.push( usuario );

            this.setState( { 
                ...this.state,
                listaUsuarios: lista
            } );
            this.clearUsuario();
            console.log( this.state );

        }else{
            console.log( "Não foi possivel adicionar, campos obrigatórios não preenchidos" );
            this.clearUsuario();
        }
    
    }


    render(){
        return(
            <div className="cadastro">
                <h2> Formumlário Cadastro </h2>
                <FormCadastro 
                    inputHandler={ this.inputHandler } 
                    addCadastro={ this.addCadastro }    
                />                
            </div>
        )
    }

}

export default Cadastro;