import React from "react";
import "./tabelaCadastro.css";

export default ( props ) => {


    /* Função que mapeia os usuarios cadastrados de 
        lista de usuarios fornecidos por props
    */
    const renderRow = () => {

        let lista = props.listaUsuarios;

        return lista.map( ( element, id ) => {
            return(
                <tr key={ id }> 
                    <td> { id }</td>
                    <td>  { element.login } </td>
                    <td> { element.dataNascimento } </td>
                    <td> {element.cpf } </td>
                    <td> { element.email } </td> 
                </tr>
            )
        } );
    }

    return(
        <div>
            <div className="panel panel-primary">
                <h2> Tabela de Usuarios Cadastrados </h2>
            </div>

            
            <div className="row panel-body">
                <table className="table table-striped">
                    <thead>
                        <tr> 
                            <th> # </th>
                            <th> Login: </th> 
                            <th> Data de Nascimento: </th>
                            <th> CPF: </th>
                            <th> Email: </th>
                        </tr>
                    </thead>

                    <tbody>
                       { renderRow() }
                    </tbody>                          

                </table>
            </div>
        </div>
        
    )

}