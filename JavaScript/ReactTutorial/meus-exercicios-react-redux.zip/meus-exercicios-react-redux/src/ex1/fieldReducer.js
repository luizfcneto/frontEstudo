const INITIAL_STATE = { value: "Valor Inicial da Funcao \"field\" dentro de reducer" }


//Só existe essa Função neste Reducer. Todas as actions são relacionadas neste Reducer
const upgradeField = function( state = INITIAL_STATE, action ){
    // console.log( action.type );

    // if( action.type === "CHANGE_VALUE" ){
    //     let newValue = action.payload;
    //     return {
    //         value: newValue
    //     }

    // }else{
    //     return INITIAL_STATE;
    // }

    switch( action.type ){
        case "CHANGE_VALUE":
            return {
                value: action.payload
            }

        default: 
            return state;
    }


} 

export default upgradeField;