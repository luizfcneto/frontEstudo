const INITIAL_STATE = { value: "Valor Incicial da Funcao \"field\" dentro de reducer" }

const upgradeField = function( state = INITIAL_STATE, action ){
    // console.log( action.type );

    // if( action.type === "CHANGE_VALUE" ){
    //     let newValue = action.payload;
    //     return {
    //         value: newValue
    //     }

    // }else{
    //     return INITIAL_STATE;
    // }

    switch( action.type ){
        case "CHANGE_VALUE":
            return {
                value: action.payload
            }

        default: 
            return state;
    }


} 

export default upgradeField;