import React from "react";
import "./formAgendamento"

import TitleH2 from "../../../../Common/TitleH2";

export default ( props ) => {
    return (   
        <div className="col-xs-4 formAgendamento">
            
            <TitleH2 
                title="Agendamento:"
                titleClass="titleClass"
            />

            <div className="row">
                

            </div>
       
        </div>
    )
}