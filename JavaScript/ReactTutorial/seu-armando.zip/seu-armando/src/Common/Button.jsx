import React from "react";
import './button.css';

export default ( props ) => {

    return (
        <div className={ props.divClassBtn }>
            <button 
                type="button" 
                className={ props.btnClass } 
                id={ props.id } 
                onClick={ props.add }
                > 
                    { props.value } 
                    
                </button>
            {/* { console.log( props.bg_color ) } */}
        </div>
    )
}