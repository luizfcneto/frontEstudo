import React from "react";
import "./header.css";

export default ( props ) => {
    return (
        <nav className="navbar navbar navbar-fixed navbar-bgcolor">

            <div className="container-fluid navbar-bgcolor">
                <div className="navbar-header">
                    <a className="navbar-brand" href="/" >
                        <img id="img_logo" alt="logo" src={ props.img_src } />
                    </a>
                </div>

                <div className="collapse navbar-collapse">
                    <ul className="nav navbar-nav"> 
                        <li role="presentation" className="active nav-li"> 
                            <a href="/"> Home </a>
                        </li> 

                        <li role="presentation" className="active nav-li"> 
                            <a href="/solicitar-orcamento"> Solicitar Orcamento </a>
                        </li>

                        <li role="presentation" className="active nav-li"> 
                            <a href="/cadastro"> Cadastro </a>     
                        </li>

                        <li role="presentation" className="active nav-li">
                            <a href="/login"> Login </a>
                        </li> 
                    </ul>

                    <form className="navbar-form navbar-right" >
                        <div className="input-group">
                            <input type="text" className="form-control" placeholder="Procurar" />
                            <span className="input-group-btn">
                                <button className="btn btn-default" type="button">Pesquisar</button>
                            </span>
                        </div>
                        
                    </form>
                </div>                
                
            </div>
            
        </nav>
        
    )
}