export function changeValue( e ){
    // console.log( e.target.value );
    return {
        type: "CHANGE_VALUE",
        payload: e.target.value
    }
}

// payload: dado que vem junto com uma ação