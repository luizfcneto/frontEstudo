import React from "react";
import "./thumbnail.css";

export default ( props ) => {

    if( props.thumbnailTitle === undefined && props.thumbnailDescription === undefined ){
        return(
            <div className="thumbnail ">
                <img className="img-fluid" src={ props.imgSrc } alt={ props.imgAlt } />
                
            </div>
        )
    } else {
        return(
            <div className="thumbnail">
                { console.log( props.srcImg ) }
                <img className="img-fluid" src={ props.imgSrc } alt={ props.imgAlt } />
    
                <div className="caption"> 
                    <h3> { props.thumbnailTitle } </h3>
                    <p> { props.thumbnailDescription } </p>
                    
                </div>
            </div>
        )
    }
    
}