import React from "react";
import "./footer.css";

export default ( props ) => {
    return (
        <div className="footer">
            <h3> Footer </h3>
            <p> 
                <b> &copy; Desenvolvido por </b> 
                <code> devluizfcneto@gmail.com </code>
                <b> &nbsp; | 2020 </b> 
            </p>
        </div> 
    )
}