import React from "react";
import "./formCadastro.css";
import Button from "../../../../Common/Button";
import Input from "../../../../Common/Input";


export default ( props ) => {
    
    return (
        <form className="form form-group">
            <div className="row"> 
                <Input 
                    divGridClass="col-xs-6 input-form"
                    inputClass="form-control" 
                    type="text" 
                    placeHolder="Email" 
                    value={ props.inputValues.email }
                    inputHandler={ props.inputHandler }
                /> 
                
                <Input 
                    divGridClass="col-xs-6 input-form"
                    inputClass="form-control"
                    type="text"
                    placeHolder="Login"
                    value={ props.inputValues.login }
                    inputHandler={ props.inputHandler }
                />                                 
            </div> 

            <div className="row">
                <Input 
                    divGridClass="col-xs-6 input-form"
                    inputClass="form-control"
                    type="password"
                    placeHolder="Senha"
                    value={ props.inputValues.senha }
                    inputHandler={ props.inputHandler }
                />

                <Input 
                    divGridClass="col-xs-6 input-form"
                    inputClass="form-control"
                    type="password"
                    placeHolder="Confirmar Senha"
                    value={ props.inputValues.confirmarSenha }
                    inputHandler={ props.inputHandler }
                />
            </div>

            <div className="row">
                <Input 
                    divGridClass="col-xs-6 input-form"
                    inputClass="form-control"
                    type="date"
                    placeHolder="dataNascimento"
                    value={ props.inputValues.dataNascimento }
                    inputHandler={ props.inputHandler }
                />

                <Input 
                    divGridClass="col-xs-6 input-form"
                    inputClass="form-control"
                    type="text"
                    placeHolder="CPF"
                    value={ props.inputValues.cpf }
                    inputHandler={ props.inputHandler }
                />

            </div> 

            <div className="row">
                <Button 
                    divClassBtn="col-xs-12 btn-cadastro"
                    btnClass="btn gray"
                    value="Cadastrar"
                    add={ props.addCadastro }
                />
            </div>
            
        </form>
    )

}