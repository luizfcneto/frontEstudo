import React from "react";
import ReactDOM from "react-dom";

ReactDOM.render(
    <COMPONETE />   
    , document.getElementById( "app" )
);