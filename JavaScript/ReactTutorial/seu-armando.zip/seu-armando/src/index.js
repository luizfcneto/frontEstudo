import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import Index from "../src/Pages/Index";
import Cadastro from "./Pages/Cadastro/Cadastro";
import { BrowserRouter, Switch, Route } from "react-router-dom"
import * as serviceWorker from './serviceWorker';
import SolicitarOrcamento from './Pages/Solicitar Orcamento/SolicitarOrcamento';
import Login from "./Pages/Login/Login";

//Componentes do Cliente
import Perfil from "./Pages/Cliente/Perfil/Perfil";
import Agendamento from "./Pages/Cliente/Agendamento/Agendamento";

ReactDOM.render(
    <BrowserRouter> 
        <Switch>
            <Route path="/cadastro" component={ Cadastro } />
            <Route path="/login" component={ Login }/>
            <Route path="/solicitar-orcamento" component={ SolicitarOrcamento } />            
            
            {/* Componentes de Cliente */}
            <Route path="/agendamento" component={ Agendamento } />
            <Route path="/perfil" component={ Perfil } />
            

            <Route path="/" component={ Index } />
            <Route path="*"></Route>
        </Switch>
    </BrowserRouter>
    ,document.getElementById( 'root' ) 
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
