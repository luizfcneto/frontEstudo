// Conectando com axios para pegar dados do backend:
import axios from "axios";

// definindo a url do axios
const URL = "http://localhost:3003/api/todos";

export const changeDescription = ( event ) => {
    return {
        type: "CHANGE_DESCRIPTION",
        payload: event.target.value
    }
}

// Como esse método faz uma requisição assincrona precisamos utilizar um middleware
export const search = () => {
    const request = axios.get( `${URL}?sort=-createdAt` );
    return {
        type: "SEARCH",
        payload: request
    }

}

// Método para adicionar uma nova tarefa. Ele faz uma requisição assincrona.
// export const adiciona = ( description ) => {

//     // sintaxe: { descricao } é equivalente a extair de um objeto o atributo descricao: { descricao: descricao }
//     const request = axios.post( URL, { description } );

//     // return {
//     //     type: "ADICIONA",
//     //     payload: request
//     // }

//     // Para executar/retornar mais de uma ação para esta action retornaremos um vetor contendo os valores 
//     // que desejamos retornar
//     return [
//         {
//             type: "ADICIONA",
//             payload: request
//         },
//         search()
//     ]
// }

//Modificando a função acima para requisitar primeiro a promise, depois executar a função search()
export const adiciona = ( description ) => {
    return ( dispatch ) => {
        axios.post( URL, { description } )
            .then( ( response ) => {
                dispatch( {
                    type: "ADICIONA",
                    payload: response.data
                } );
            } )

            .then( ( response ) => {
                dispatch( search() );
            } );
    }
}

//função que vai marcar uma tarefa como concluida:
export const markAsDone = ( todo ) => {
    return ( dispatch ) => {
        axios.put( `${URL}/${todo._id}`, { ...todo, done: true } )
            .then( ( response ) => {
                // Não necessária
                dispatch( {
                    type: "MARKED_AS_DONE",
                    payload: response.data
                } );
            } )

            .then( ( response ) => {
                return dispatch( search() );
            } )
    }
}


//função que vai marcar uma tarefa como pendente:
export const markAsPending = ( todo ) => {
    return ( dispatch ) => {
        axios.put( `${URL}/${todo._id}`, { ...todo, done: false } )
            .then( ( response ) => {
                return dispatch( search() );
            } );
    }
}