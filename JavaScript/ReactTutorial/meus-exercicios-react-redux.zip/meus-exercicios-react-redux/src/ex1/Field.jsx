import React from "react";

// Importando o método connect:
import { connect } from "react-redux";

// Importando o método bindActionCreators que faz a comunicação deste componente com o as Ações criadas
import { bindActionCreators } from "redux";

// Importando a função Action para este Componente:
import { changeValue } from "./fieldActions";


class Field extends React.Component {
    // constructor ( props ) { 
    //     super(props);

    //     this.state = {
    //         value: props.initialValue
    //     }

    //     this.handleChange = this.handleChange.bind( this );
    // }

    // handleChange( event ) {
    //     this.setState( {
    //         value: event.target.value
    //     } );
    // }

    render(){
        return (
            <div>
                <h1> Componente Campo: </h1>
                <label> { this.props.value }</label> <br/>
                <input onChange={ this.props.changeValue } value={ this.props.value } />
            </div>
        )
    }
    
}

// Mapeando as propriedades específicas do store para as propriedades para o Componente Field:
function mapStateToProps( state ){  
    return {
        value: state.field.value
    }
}

function mapDispatchToProps( dispatch ){
    return bindActionCreators( { changeValue }, dispatch )
}

export default connect( mapStateToProps, mapDispatchToProps )( Field );