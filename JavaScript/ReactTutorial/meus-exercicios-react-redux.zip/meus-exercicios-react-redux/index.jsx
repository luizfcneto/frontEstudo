import React from "react";
import ReactDOM from "react-dom";
import Field from "./src/ex1/Field";
import fieldReducer from "./src/ex1/fieldReducer";

/* 
    Importando funções do Redux:
    - createStore( reducers ):
        Cria o objeto store
        o objeto store é composto por propriedades/atributos, sendo cada propriedade/atributo
        controlado por um reducer.

    - combineReducers( objeto_com_funcoes_reducers ):
        Cria um objeto composto por reducers,
        cada reducer aponta/refrencia/ é direcionado para uma propriedade de store

        
    Resumindo: 
        store é criado a partir de dois métodos em sequencia:
            1. combineReducers( objetocontendofuncoesreducers )
            2. createStore( 1 )

*/
import { combineReducers, createStore } from "redux";


/*
    Importando módulo do React-Redux:
    - Provider:
        Um Componente que pega o state de store e passa para os componentes internos.

 */
import { Provider } from "react-redux";

/*
    atribuindo à reducers o resultado da função combineReducers( objeto com métodos reducers )
*/
const reducers = combineReducers( {
    
    // field: () => ( {
    //     value: "Valor Incicial da Funcao \"field\" dentro de reducer"
    // } )
    
    field: fieldReducer

} )

ReactDOM.render(
    <Provider store={ createStore( reducers ) }>
        <Field initialValue="Valor inicial" />
    </Provider>
    , document.getElementById( "app" )
);