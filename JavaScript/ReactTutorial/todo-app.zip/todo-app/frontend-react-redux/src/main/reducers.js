import { combineReducers } from "redux";

/*
    Importando reducers o módulo: todoReducer 
     que é especifico para todas as ações relacionadas com o Componente Todo
*/
import todoReducer from "../Todo/todoReducer";

// reducer mestre do nosso projeto
const rootReducer = combineReducers( {

    // // cada reducer do nosso projeto, função abaixo mockado
    // todo: () => {

    //     // Inicialmente retornando um objeto mockado para testes
    //     return {
    //         description: "Ler Livro",
    //         list: [ {
    //             _id: 1,
    //             description: "Pagar fatura do cartão",
    //             done: true
    //         }, {
    //             _id: 2,
    //             description: "Reunião com a equipe às 10 horas",
    //             done: false
    //         }, {
    //             _id: 3,
    //             description: "Consulta médica na terça depois do almoço",
    //             done: false
    //         }, {
    //             _id: 4,
    //             description: "Teste",
    //             done: false
    //         } ]
    //     }

    todo: todoReducer


} );

export default rootReducer;