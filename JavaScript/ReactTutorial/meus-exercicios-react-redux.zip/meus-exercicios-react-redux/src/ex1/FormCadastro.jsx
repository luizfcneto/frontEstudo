import React from "react";
import Button from "../Commons/Button";
import Input from "../Commons/Input";


export default ( props ) => {
    
    return (
        <form className="form">
            <div className="row"> 
                <Input 
                    divGridClass="col-xs-6 input-form"
                    inputClass="form-control" 
                    type="text" 
                    placeHolder="Email" 
                    inputHandler={ props.inputHandler }
                /> 
                
                <Input 
                    divGridClass="col-xs-6 input-form"
                    inputClass="form-control"
                    type="text"
                    placeHolder="Login"
                    inputHandler={ props.inputHandler }
                />                                 
            </div>

            <div className="row">
                <Input 
                    divGridClass="col-xs-6 input-form"
                    inputClass="form-control"
                    type="password"
                    placeHolder="Senha"
                    inputHandler={ props.inputHandler }
                />

                <Input 
                    divGridClass="col-xs-6 input-form"
                    inputClass="form-control"
                    type="password"
                    placeHolder="Confirmar Senha:"
                    inputHandler={ props.inputHandler }
                />
            </div>
            
            <div className="row">
                <Input 
                    divGridClass="col-xs-6 input-form"
                    inputClass="form-control"
                    type="date"
                    placeHolder="dataNascimento"
                    inputHandler={ props.inputHandler }
                />

                <Input 
                    divGridClass="col-xs-6 input-form"
                    inputClass="form-control"
                    type="text"
                    placeHolder="CPF"
                    inputHandler={ props.inputHandler }
                />

            </div> 

            <div className="row">
                <Button 
                    divClassBtn="col-xs-12 btn-cadastro"
                    btnClass="btn btn-primary"
                    value="Cadastrar"
                    add={ props.addCadastro }
                />
            </div>
            
        </form>
    )

}