import React from "react";

// Importando o método connect:
import { connect } from "react-redux";

// Importando o método bindActionCreators que faz a comunicação deste componente com o as Ações criadas
import { bindActionCreators } from "redux";

// Importando a função changeValue do módulo fieldActions para este Componente:
import { changeValue } from "./fieldActions";


class Field extends React.Component {

    /* 
        props agora é mapeado para este Componente através do método mapStateToProps( state )
         este state é fornecido pelo Redux ( store )
    */
    // constructor ( props ) { 
    //     super(props);

    //     this.state = {
    //         value: props.initialValue
    //     }

    //     this.handleChange = this.handleChange.bind( this );
    // }

    /* 
        Função que anterior era manipulada internamente do Componente Field agora fica
         em arquivo separado js. fieldActions
    
    */
    // handleChange( event ) {
    //     this.setState( {
    //         value: event.target.value
    //     } );
    // }

    render(){
        return (
            <div>
                <h1> Componente Campo: </h1>
                <label> { this.props.value } </label> <br/>
                <input onChange={ this.props.changeValue } value={ this.props.value } />
            </div>
        )
    }
    
}

// Mapeando states específicos do store para as propriedades ( props ) para o Componente Field:
function mapStateToProps( state ){  

    // retorna um objeto contendo o atributo valor que contem: valor do estado do reducer field
    return {
        value: state.field.value
    }
}

// Mapeando dispatch com propriedades do Componente Field
function mapDispatchToProps( dispatch ){
    return bindActionCreators( { changeValue }, dispatch )
}

/* 
    Exportando de forma padrão utilizando o método connect ( do react-redux ) contendo os 
     parametros mapStateToProps e mapDispatchToProps, e fornecendo também o nome do Componente
     que estamos exportando ( Field )

*/
export default connect( mapStateToProps, mapDispatchToProps )( Field );