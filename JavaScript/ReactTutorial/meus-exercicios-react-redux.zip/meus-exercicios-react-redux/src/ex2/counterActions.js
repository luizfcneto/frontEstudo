

// Como a função inc é uma "action" retornará um objeto contendo o atributo type ESPECÍFICO para esta funcao 
export function inc() {
    return {
        type: "INCREMENT"
    }
}

// função dec também é uma "action", logo retornará obrigatóriamente o atributo type ESPECÍFICO para esta funcao
export function dec() {
    return {
        type: "DECREMENT"
    }
}

// função "action" que modifica o conteudo, portanto deverá receber o evento como parametro 
export function alterarConteudo( event ) {
    return {
        type: "CHANGE",
        payload: event.target.value
    }

}