import React, { Component } from "react";

// Importando o Componente AXIOS 
import axios from "axios";

import PageHeader from "../Template/PageHeader";
import TodoForm from "./TodoForm";
import TodoList from "./TodoList";

const URL = "http://localhost:3003/api/todos";

class Todo extends Component {

    constructor( props ){
        super( props );
        
        this.state = {
            description: "",
            list: []
        }
        this.handleChange = this.handleChange.bind( this );
        this.handleAddEvent = this.handleAddEvent.bind( this );
        this.removeElement = this.removeElement.bind( this );

        this.refreshList();
    }

    // Atualiza exibição da lista de tarefas
    refreshList() {
        console.log( "Lista exibida atualizada" );
        axios.get( `${URL}?sort=-createdAt` ).then( ( resposta ) => {
            // console.log( resposta.data );
            // console.log( resposta.status );
            // console.log( resposta );

            this.setState( {
                ...this.state,
                description: "",
                list: resposta.data
            } );
        } );
    }

    // Adiciona Novas tarefas na lista
    handleAddEvent() {
        console.log( "Evento de Add.." );
        // // console.log( this );
        // console.log( this.state.description );
        
        const description = this.state.description;
        
        // Método POST para enviar o dado de descrição do formulário para nossa API
        axios.post( URL, { description } ).then( ( resposta ) => {
                // console.log( resposta );
                // console.log( resposta.data );
                if( resposta.status === 201 ){
                    console.log( "FUNCIONOU!" );
                }                

                this.refreshList();
            } );
    
    }

    // Remove Elementos da Lista pelo critério do id:
    removeElement( todo ) {
        console.log( "Evento de remoção de elemento" );

        axios.delete( `${URL}/${todo._id}` ).then( ( resposta ) => {
            console.log( resposta );
            console.log( resposta.status );
            console.log( "Elemento " + todo.description + " removido com sucesso" );
            this.refreshList();
        });
    }

    /* 
        HandleChange vai ser invocado pelo componente filho TodoForm quando o 
        usuario alterar o valor do input. tem como parametro fornecido um e ( evento )    
    */
    handleChange( e ){
        // console.log( e.target.value );
        this.setState( {
            ...this.state,
            description: e.target.value
        } );   
    }

    render(){
        return (
            <div>
                <PageHeader name="Tarefas" small="Cadastro" />
                <TodoForm 
                    description={ this.state.description }
                    handleChange={ this.handleChange }
                    handleAddEvent={ this.handleAddEvent } 
                />            
                <TodoList
                    list={ this.state.list }
                    removeElement= { this.removeElement }
                />    
            </div>
        )
    }
}

export default Todo;