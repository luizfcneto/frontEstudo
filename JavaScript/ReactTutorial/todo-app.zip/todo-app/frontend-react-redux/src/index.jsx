import React from "react";
import ReactDOM from "react-dom";

/* Importando o módulo e método do Redux e reducers q eu criei
    Importando o método applyMiddleware do redux para fazer a ponte de 
    comunicação de uma promise/requisicao com o reducer
*/
 import { applyMiddleware, createStore } from "redux";
 import promise from "redux-promise";

 import { Provider } from "react-redux";
import reducers from "./main/reducers";

import App from "./main/app";

// Configurando o projeto com o plugin do Redux-DevTools
const devTools = 
    window.__REDUX_DEVTOOLS_EXTENSION__ 
    &&
    window.__REDUX_DEVTOOLS_EXTENSION__();


/* 
    Adicionando no parametro createStore a constante devTools para conectar com
 o plugin

    adicionando o método applyMiddleware com o promise:
*/
const store = applyMiddleware( promise )( createStore )( reducers, devTools );

ReactDOM.render(
    <Provider store={ store }>
        <App />
    </Provider>
    , document.getElementById( "app" )
);