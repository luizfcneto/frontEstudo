const INITIAL_STATE = { step: 1, number: 0 }

/* Reducer só possui uma única função e dentro dela verificaremos qual ação está 
 sendo fornecida como parametro, juntamente com o estado da aplicação
*/
export default function( state = INITIAL_STATE, action ){

    console.log( "Entramos no Switch do reducer que verifica qual a ação está sendo chamada" );
    switch( action.type ){
        case "INCREMENT":
            console.log( state.number, state.step , "+");
            return {
                ...state,
                number: state.number + state.step
            }

        case "DECREMENT":
            console.log( state.number, state.step, "-" );
            return {
                ...state,
                number: state.number - state.step
            }

        case "CHANGE":
            
            return {
                ...state, 
                step: +action.payload
            }

        default:
            console.log( "Retornar padrão:", INITIAL_STATE )
            return state;
    }


}