import React from "react";
import "./index.css";

import Header from "../../Common/Header";
import Section from "./Section";
import Article from "./Article";
import Aside from "./Aside";
import Footer from "../../Common/Footer";

export default ( props ) => {
    return (
        <div className="all">
            <Header />
            
            <div className="container-fluid">
                
                <div className="title">
                    <h2> Home </h2>
                </div>
                
                <div className="row">
                    <Section />
                </div>
                
                <div className="row">     
                    <div className="col-xs-9">
                        <Article />
                    </div>      
                    
                    <div className="col-xs-3">
                        <Aside />
                    </div>

                </div>

            </div>

            <Footer />

        </div>
    )
}