import React from "react";
import IconButton from "../Template/iconButton";

export default ( props ) => {

    const renderRows = () => {

        // let list;
        const list = props.list || [];

        // return (
        //     <tr> 
        //         <td> Teste </td>
        //         <td> 
        //             <IconButton 
        //                 style="danger" 
        //                 icon="trash-o"
        //                 onClick={ () => props.removeElement( todo ) }
        //             >
        //            </IconButton>
        //         </td>
        //     </tr>
        // )


        return list.map( ( todo ) => {
            <tr key={ todo._id }>
                <td> { todo.description } </td>
                <td> 
                    <IconButton 
                        style="btn-outline-danger" 
                        icon="fas fa-trash"
                        onClick={ () => props.removeElement( todo ) }
                        >
                    </IconButton>
                </td>
            </tr>
        } );
    
    }
    
    return ( 
        <table className="table table-striped">
            
            <thead>
                <tr>
                    <th> Descrição da Tarefa </th>
                    <th> Ações </th> 
                </tr>
            </thead>

            <tbody>
                <tr>
                    <td> Teste </td>
                </tr>
                { renderRows() }
            </tbody>

        </table>
    )
}