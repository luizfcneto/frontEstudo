import "../style/header.css";

export function Header() {
    
    const initialExp = 0;
    const endExp = 600;

    return (
        <header className="container-header">
            <span> <strong> { initialExp } </strong> xp </span>

            <div className="experience-bar">
                <div className="experience-gained"> 
                    <span className="current-exp"> 300 xp </span>
                </div>
            </div>
            
            <span> <strong> { endExp } </strong> xp </span>
        </header>
    );
}