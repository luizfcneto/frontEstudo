import React, { Component } from "react";

import PageHeader from "../Template/PageHeader";
import TodoForm from "../Todo/TodoForm";
import TodoList from "../Todo/TodoList";

class Todo extends Component {

    constructor( props ){
        super( props );
        
        this.state = {
            description: "",
            list: []
        }
        this.handleChange = this.handleChange.bind( this );
        this.handleAddEvent = this.handleAddEvent.bind( this );
    }

    handleAddEvent() {
        console.log( "Evento de Add.." );
        // console.log( this );
        console.log( this.state.description );
    }

    /* 
        HandleChange vai ser invocado pelo componente filho TodoForm quando o 
        usuario alterar o valor do input. tem como parametro fornecido um e ( evento )    
    */
    handleChange( e ){
        // console.log( e.target.value );
        this.setState( {
            ...this.state,
            description: e.target.value
        } );    
    }

    render(){
        return (
            <div>
                <PageHeader name="Tarefas" small="Cadastro" />
                <TodoForm 
                    description={ this.state.description }
                    handleChange={ this.handleChange }
                    handleAddEvent={ this.handleAddEvent } 
                />            
                <TodoList />    
            </div>
        )
    }
}

export default Todo;