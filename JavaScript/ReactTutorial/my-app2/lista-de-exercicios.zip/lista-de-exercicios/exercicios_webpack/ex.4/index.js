/*
 * Quando o arquivo é referenciado ele será 
 * considerado para a geração do arquivo bundle.js
 */
require('./duvidaCruel')